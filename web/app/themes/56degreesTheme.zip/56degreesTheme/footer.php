<!-- Site footer markup goes here -->

<?php get_template_part( 'templates/partials/document-close' );
