export default {
    name: "pagination",
    template: '#vue-pagination',
    // Be shure to include .php with vue-template on embeding

    data() {
        return {}
    },

    props: {},
}