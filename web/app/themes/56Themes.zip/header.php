<?php get_template_part( 'templates/partials/document-open' ); ?>

<!-- Site header markup goes here -->
