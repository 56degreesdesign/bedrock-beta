<template id="vue-child-component" v-if="false">
    <div class="w-full">
		<p class="mt-4 text-lg leading-6 text-indigo-200">Vue Child Component</p>
    </div>
</template>
