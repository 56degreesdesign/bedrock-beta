module.exports = function () {
    console.log('example.js Loaded');
};